CREATE TABLE customers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  service_tier TEXT NOT NULL,
  billing_terms TEXT NOT NULL
);

CREATE TABLE deliveries (
  id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL REFERENCES customers(id),
  region TEXT NOT NULL,
  status TEXT NOT NULL,
  assigned_driver_id TEXT,
  proof_of_delivery_ref TEXT,
  completed_at TIMESTAMP
);

CREATE TABLE incidents (
  id TEXT PRIMARY KEY,
  severity INTEGER NOT NULL,
  commander_role TEXT NOT NULL,
  communications_role TEXT NOT NULL,
  customer_impact TEXT NOT NULL,
  status TEXT NOT NULL,
  opened_at TIMESTAMP NOT NULL,
  resolved_at TIMESTAMP
);

CREATE TABLE customer_credits (
  id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL REFERENCES customers(id),
  incident_id TEXT REFERENCES incidents(id),
  amount_cents INTEGER NOT NULL,
  approved_by_role TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL
);

CREATE TABLE deployment_records (
  id TEXT PRIMARY KEY,
  service_name TEXT NOT NULL,
  release_manager_role TEXT NOT NULL,
  approved_by_role TEXT NOT NULL,
  rollback_owner_role TEXT NOT NULL,
  deployed_at TIMESTAMP NOT NULL
);

