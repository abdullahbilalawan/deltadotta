# Operating model

## Executive structure

The Chief Operating Officer reports to the Chief Executive Officer.
The Chief Technology Officer reports to the Chief Executive Officer.
The Finance Controller reports to the Chief Executive Officer.

The Chief Operating Officer owns delivery operations, customer operations, and
carrier outcomes. The Chief Technology Officer owns platform reliability,
security, data infrastructure, and engineering delivery.

## Cross-functional decision rules

- The Platform Engineering Lead is the final technical approver for production changes.
- The Fleet Operations Lead is the final operational owner for regional dispatch safety.
- The VP Customer Operations owns the content and timing of enterprise communications.
- The Finance Controller owns invoice correctness and credit controls above delegated limits.
- The Security Lead can block any production change carrying an unresolved critical security finding.

## Reporting clarification

The Release Manager reports to the Chief Operating Officer so that the release
calendar remains aligned with carrier operations and customer commitments.

## Required handoffs

1. Engineering gives Fleet Operations a release-impact summary before a dispatch-affecting change.
2. Fleet Operations gives Customer Operations an impact estimate during a delivery incident.
3. Customer Operations gives Finance every approved credit with an incident reference.
4. Dispatch gives Billing a completed-delivery event only after proof of delivery is recorded.

