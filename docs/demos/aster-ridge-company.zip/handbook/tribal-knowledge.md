# Things experienced operators know

These practices are real operating knowledge but have historically lived in
chat messages and individual memory.

## Release timing

- Avoid dispatch-service releases between 4:00 PM and 8:00 PM local time. That is the evening delivery peak.
- Friday releases are allowed, but only for urgent fixes with a named rollback owner.
- A green test suite is not sufficient when route volume is more than 20 percent above forecast.
- The Platform Engineering Lead usually asks Fleet Operations for a verbal confirmation before a dispatch schema migration.

## Incident behavior

- When ETA accuracy fails but orders still move, Support sees the incident before monitoring does.
- If three enterprise customers report the same symptom within fifteen minutes, the Customer Support Lead should declare an incident instead of opening separate tickets.
- The first external update should state impact and mitigation. Do not speculate about root cause.
- Carrier outages are operational incidents unless the dispatch API or routing engine is also degraded.

## Billing reality

- A delivery completion event can arrive before the signed proof-of-delivery image.
- Billing must wait for the proof reference for regulated medical deliveries.
- Credits promised in an incident call are not valid until they are recorded with an approver and incident identifier.

## Escalation shortcuts

- Driver safety goes directly to the Fleet Operations Lead.
- Possible credential exposure goes directly to the Security Lead.
- Conflicting customer promises go to the VP Customer Operations.
- A conflict between operational continuity and technical risk goes to both the Chief Operating Officer and Chief Technology Officer.

