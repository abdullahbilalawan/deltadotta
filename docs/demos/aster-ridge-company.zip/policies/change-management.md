# Production change management

## Standard changes

The Release Manager coordinates the release calendar, gathers readiness
evidence, and records the decision. The Release Manager must not approve a
production deployment. The Platform Engineering Lead is the accountable
deployment approver.

Required evidence:

- Passing automated tests
- Named deployer and rollback owner
- Monitoring and rollback plan
- Security review when authentication, authorization, or customer data changes
- Fleet Operations acknowledgement for dispatch-affecting changes

## Emergency changes

The Incident Commander may request an emergency change. The Platform
Engineering Lead approves it. If a critical security finding is involved, the
Security Lead must also approve. All missing standard evidence becomes a
follow-up item with an owner and due date.

## Freeze windows

- No routine dispatch changes during the evening delivery peak.
- Quarter-end billing changes require Finance Controller acknowledgement.
- A freeze can be lifted only by the Platform Engineering Lead and the affected business owner.

