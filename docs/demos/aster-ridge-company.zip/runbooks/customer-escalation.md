# Enterprise customer escalation

## Ownership

The Customer Support Lead owns intake and initial triage. The VP Customer
Operations owns enterprise communication and service recovery. The Platform
Engineering Lead owns technical mitigation. The Fleet Operations Lead owns
carrier and driver mitigation.

## Severity rules

- Severity 1: Multiple regions cannot dispatch or customer data may be exposed.
- Severity 2: One region is materially degraded or one enterprise customer cannot operate.
- Severity 3: Workaround exists and delivery completion remains reliable.

## Credit authority

- Customer Support Lead may approve up to 1,000 dollars.
- VP Customer Operations may approve up to 25,000 dollars.
- Finance Controller approves anything larger or any nonstandard contract remedy.

## Handoff record

Every escalation must include the customer, affected orders, incident identifier,
current owner, next update time, promised remedy, and approving role.

