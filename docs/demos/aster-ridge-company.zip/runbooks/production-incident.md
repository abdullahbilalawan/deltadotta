# Production incident runbook

## Trigger

Declare an incident when customer-facing availability falls below target, data
integrity is uncertain, or multiple enterprise customers report the same failure.

## Roles

### Incident Commander

- Purpose: Coordinate technical recovery and keep one authoritative timeline.
- Reports to: Platform Engineering Lead
- Owns: Severity, technical workstreams, mitigation decision, recovery criteria
- Authority: May initiate a rollback when impact is increasing
- Inputs: Monitoring alerts, support reports, deploy history
- Outputs: Incident status, mitigation decision, recovery declaration
- Collaborators: Communications Lead, Fleet Operations Lead, Security Lead

### Communications Lead

- Purpose: Keep customer and executive communication accurate.
- Reports to: VP Customer Operations
- Owns: Status page, enterprise briefing, executive summary
- Authority: May publish confirmed impact and mitigation; must not publish an unverified root cause
- Inputs: Incident Commander updates, customer impact assessment
- Outputs: Status updates, customer briefings
- Collaborators: Customer Support Lead, Incident Commander

## Sequence

1. Customer Support Lead or monitoring declares the incident.
2. Platform Engineering Lead assigns the Incident Commander.
3. Fleet Operations Lead confirms operational impact by region.
4. Communications Lead publishes confirmed impact within twenty minutes.
5. Security Lead joins immediately when access, privacy, or data exposure is possible.
6. Incident Commander declares recovery only after technical and operational checks pass.

## Prohibited actions

- Do not delete logs during an incident.
- Do not rotate credentials unless Security coordinates the action.
- Do not issue customer credits from the engineering incident channel.
- Do not claim root cause before evidence is reviewed.

