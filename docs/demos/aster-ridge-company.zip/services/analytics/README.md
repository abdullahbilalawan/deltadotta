# Analytics platform

The analytics platform provides operational and financial reporting.

- Data Platform Lead owns pipeline reliability, metric definitions, and certified datasets.
- Finance Controller approves revenue metric definitions.
- Fleet Operations Lead approves delivery-performance definitions.
- Security Lead approves access to customer-level datasets.

If a source dataset is corrupted, the Data Platform Lead may quarantine it even
when doing so delays executive reporting.

