# Billing service

Billing converts completed deliveries into customer invoices.

## Owners

- Business owner: Finance Controller
- Data owner: Data Platform Lead
- Customer remedy owner: VP Customer Operations

## Invariants

1. A regulated medical delivery cannot be invoiced without a proof reference.
2. Every credit requires an approving role and incident or case identifier.
3. Replayed completion events must not produce duplicate invoice lines.
4. Finance Controller can block invoice generation when delivery data is inconsistent.

