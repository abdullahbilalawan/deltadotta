import assert from "node:assert/strict";
import test from "node:test";
import { canInvoice, validCredit } from "./invoice.ts";

test("regulated medical deliveries wait for proof", () => {
  assert.equal(canInvoice({
    id: "delivery-1",
    customerId: "customer-1",
    regulatedMedical: true,
  }), false);
});

test("credits retain an accountable role and case", () => {
  assert.equal(validCredit({
    amountCents: 50000,
    approvedByRole: "Customer Support Lead",
    caseReference: "incident-42",
  }), true);
});

