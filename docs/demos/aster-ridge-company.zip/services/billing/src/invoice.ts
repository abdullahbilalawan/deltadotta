export type CompletedDelivery = {
  id: string;
  customerId: string;
  regulatedMedical: boolean;
  proofOfDeliveryRef?: string;
};

export type ApprovedCredit = {
  amountCents: number;
  approvedByRole: string;
  caseReference: string;
};

export function canInvoice(delivery: CompletedDelivery) {
  if (delivery.regulatedMedical && !delivery.proofOfDeliveryRef) return false;
  return true;
}

export function validCredit(credit: ApprovedCredit) {
  return credit.amountCents > 0
    && credit.approvedByRole.trim().length > 0
    && credit.caseReference.trim().length > 0;
}

