# Dispatch service

The dispatch service assigns delivery work to drivers and carrier partners.
It is customer critical and has direct driver-safety implications.

## Ownership

- Service owner: Platform Engineering Lead
- Operational partner: Fleet Operations Lead
- Incident intake: Customer Support Lead
- Security reviewer: Security Lead

## Change contract

Dispatch-affecting changes require a rollback plan, regional impact assessment,
and Fleet Operations acknowledgement. Production deployment approval belongs to
the Platform Engineering Lead.

## Events produced

- `delivery.assigned`
- `delivery.started`
- `delivery.completed`
- `delivery.failed`

