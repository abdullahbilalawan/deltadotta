export type Delivery = {
  id: string;
  region: string;
  priority: "standard" | "medical" | "emergency";
  proofOfDeliveryRequired: boolean;
};

export type Driver = {
  id: string;
  region: string;
  available: boolean;
  medicalCertified: boolean;
};

export function eligibleDrivers(delivery: Delivery, drivers: Driver[]) {
  return drivers.filter((driver) => {
    if (!driver.available || driver.region !== delivery.region) return false;
    if (delivery.priority === "medical" && !driver.medicalCertified) return false;
    return true;
  });
}

export function selectDriver(delivery: Delivery, drivers: Driver[]) {
  return eligibleDrivers(delivery, drivers)[0] ?? null;
}

