# Confidence and gaps report

DeltaDotta packages operating context. This report lists what is backed by source evidence, what still depends on template assumptions, and what the target AI provider must enforce.

## Package confidence
- Organization: Northstar Engineering
- Launch status: preflighted
- Repository evidence sources: 4
- Role count: 5

## Source fingerprints
- Repository: CODEOWNERS — fnv1a-0a467578
- Repository: PRODUCT-KNOWLEDGE.md — fnv1a-5bd3f397
- Repository: README.md — fnv1a-b0e5fe6a
- Repository: RUNBOOK.md — fnv1a-46ec50ae

## Open issues
- No structural lint issues found in the role map.

## Assumptions and limits
- Template defaults are present. Review any role that has not been refined from local evidence.
- First-shift status is preflighted, not runtime-enforced. It means the generated contract passed deterministic package checks.
- DeltaDotta does not enforce provider tool permissions. Connected AI tools must enforce real access, credentials, approvals, and audit logs.
- Repository source hashes detect changed source content after launch, but they do not prove the new content is correct.

## Recommended next review
1. Confirm each role's owner and authority with a human accountable owner.
2. Run `deltadotta check` after source files change or move.
3. Test the first-shift prompt in the target provider before giving the role tool access.
4. Configure provider-side permissions, logs, approvals, and revocation outside DeltaDotta.
