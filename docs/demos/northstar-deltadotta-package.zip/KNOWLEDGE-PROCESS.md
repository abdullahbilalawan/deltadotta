# Tribal knowledge operating process

DeltaDotta is not only a hierarchy generator. It turns scattered team memory into a reusable operating process for AI-assisted work.

## 1. Capture the sources
Bring in runbooks, README files, workflow files, CODEOWNERS, meeting notes, support notes, and role descriptions. Keep the original source names visible.

## 2. Link knowledge to owners
Every important fact should answer three questions: who owns it, what decision it affects, and when it must be escalated.

## 3. Convert memory into role skills
Role skills carry mission, authority, inputs, outputs, handoffs, escalation, and required knowledge. They are designed to be used inside Claude, Codex, ChatGPT, or another model workflow as operating context.

## 4. Verify before trusting
Run a safe first-shift scenario. The first verification is read-only by default: no deployments, restarts, credentials, production changes, or record edits.

## 5. Keep it fresh
Use `deltadotta check` after source files move or change. Refresh the package when ownership, authority, or the source of truth changes.

## Current evidence
- Software Launchpad template (note) — Default software roles and relationships. Confirmed launch answers replace only authority, handoff, and escalation assumptions.
- Repository: CODEOWNERS (repository) — * @northstar/engineering
- Repository: PRODUCT-KNOWLEDGE.md (repository) — # Product and tribal knowledge Northstar Checkout helps merchants recover failed payments before churn. ## Product details - The checkout API is customer-facing and must keep authorization latency under 400ms. - Failed deployment checks usually mean webhook delivery or payment-in
- Repository: README.md (repository) — # Northstar Checkout Northstar Checkout is a small software service used for the DeltaDotta product demo. The team ships through pull requests and requires a release-owner approval before production deployment.
- Repository: RUNBOOK.md (repository) — # Release runbook - Engineering Lead owns delivery priorities and incident escalation. - DevOps / Platform owns deployment readiness and environment checks. - Production releases require explicit approval from the Engineering Lead. - Failed checks are handed back to the Software 

## Current owner map
- Engineering Lead: owns Engineering delivery, Technical risk; escalates to no escalation target.
- DevOps / Platform Engineer: owns Deployment pipeline, Observability, Incident response; escalates to Engineering Lead.
- Software Engineer: owns Application implementation, Code quality; escalates to Engineering Lead.
- Product Designer: owns Interaction design, Design specifications; escalates to Engineering Lead.
- QA Engineer: owns Release validation, Quality risk; escalates to Engineering Lead.
