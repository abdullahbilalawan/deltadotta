# Northstar Engineering

Give demo-workspace a safe, evidence-backed software operating model.

## Roles
- **Engineering Lead** (Engineering) — Maya Chen owns delivery direction, technical tradeoffs, and production-risk escalation.
- **DevOps / Platform Engineer** (Engineering) — Keep deployment, observability, and incident response dependable without bypassing safety boundaries.
- **Software Engineer** (Engineering) — Build and maintain product capabilities within the agreed technical approach.
- **Product Designer** (Product) — Turn product intent into coherent, usable experiences.
- **QA Engineer** (Engineering) — Make release confidence and customer-impacting risk visible before delivery.

## How to use this package
Use the role skills as constrained operating context. Preserve the reporting and escalation relationships before delegating work across roles.

## Managing tribal knowledge
Start with `KNOWLEDGE-PROCESS.md` and `GAPS.md`. DeltaDotta captures source material, links it to owners and decision boundaries, packages it into role skills, preflights a safe first-shift scenario, and gives you a refresh loop when the source of truth changes.
