# Provider import guide

This is a provider-neutral DeltaDotta organization package. Keep the folder intact when possible. Start with `ORGANIZATION.md`, then add role files from `roles/` as reusable context or skills in your selected model workflow.

## Claude.ai custom skills

Each folder under `roles/` is a Claude-compatible custom skill. To import one role:

1. Create a ZIP whose root contains the role folder (for example, `devops-platform-engineer/SKILL.md`).
2. In Claude, open **Customize → Skills**.
3. Choose **+ → Create skill → Upload a skill** and select the ZIP.
4. Enable the imported skill, then start a new chat and ask Claude to perform the role's first-shift scenario.

Claude imports focused skills one at a time; the complete DeltaDotta ZIP remains the portable organization package. Code execution and file creation must be enabled in Claude for Skills to appear.

Do not treat the package as an access-control system. It describes roles, authority, and delegation; your target provider or connected tools must enforce real permissions.
