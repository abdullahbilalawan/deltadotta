# Authority boundaries

## Engineering Lead
- Resolve technical tradeoffs
- Pause unsafe delivery

## DevOps / Platform Engineer
- Platform team may stop or roll back an unsafe deployment.

## Software Engineer
- Make implementation decisions within the agreed architecture

## Product Designer
- Approve interaction quality

## QA Engineer
- Block a release that fails agreed quality criteria
