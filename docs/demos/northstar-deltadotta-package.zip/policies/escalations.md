# Escalation paths

- Engineering Lead → no escalation target
- DevOps / Platform Engineer → Engineering Lead
- Software Engineer → Engineering Lead
- Product Designer → Engineering Lead
- QA Engineer → Engineering Lead
