# Collaboration and handoffs

- Engineering Lead is a top-level role; collaborates with DevOps / Platform Engineer, Software Engineer, Product Designer, QA Engineer.
- DevOps / Platform Engineer reports to Engineering Lead; collaborates with Engineering Lead, Product Engineering.
- Software Engineer reports to Engineering Lead; collaborates with Engineering Lead, DevOps / Platform Engineer, QA Engineer.
- Product Designer reports to Engineering Lead; collaborates with Software Engineer, QA Engineer.
- QA Engineer reports to Engineering Lead; collaborates with Software Engineer, DevOps / Platform Engineer.
