# Installed Codex context

DeltaDotta maintains the provider entrypoint in `AGENTS.md` at the repository root. The full role context lives at `.deltadotta/launchpad/providers/codex/AGENTS.md`.
